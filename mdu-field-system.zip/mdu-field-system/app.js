
let banco = JSON.parse(localStorage.getItem("mduOS")) || []
const lista = document.getElementById("lista")

function trocarTema(tema){
if(tema=="verde"){
document.documentElement.style.setProperty('--cor-primaria','#00b894')
}
if(tema=="claro"){
document.documentElement.style.setProperty('--cor-primaria','#e60000')
}
if(tema=="azul"){
document.documentElement.style.setProperty('--cor-primaria','#0984e3')
}
if(tema=="escuro"){
document.documentElement.style.setProperty('--cor-primaria','#6c5ce7')
}
}

function pegarGPS(){
navigator.geolocation.getCurrentPosition(pos=>{
let lat = pos.coords.latitude
let lon = pos.coords.longitude
localStorage.setItem("gps",lat+","+lon)
})
}
pegarGPS()

function salvarOS(){

let os = {
data:data.value,
cidade:cidade.value,
endereco:endereco.value,
predio:predio.value,
andarDio:andarDio.value,
naps:naps.value,
hps:hps.value,
tipo:tipo.value,

materiais:{
drop:drop.value,
conector:conector.value,
nap:nap.value,
cto:cto.value
},

obs:obs.value,
gps:localStorage.getItem("gps")
}

banco.push(os)
localStorage.setItem("mduOS",JSON.stringify(banco))
render()
}

function render(){

lista.innerHTML=""

banco.forEach(os=>{

let li=document.createElement("li")

li.innerHTML=`
📅 ${os.data}<br>
🏢 ${os.predio}<br>
📍 ${os.endereco}<br>
⚙️ ${os.tipo}<br>
HPs: ${os.hps} | NAPs: ${os.naps}
`

lista.appendChild(li)

})
}

render()

function exportarWhats(){

let texto="RELATORIO TECNICO MDU\n\n"

banco.forEach(os=>{

texto+=`
Data: ${os.data}
Predio: ${os.predio}
Endereco: ${os.endereco}
Servico: ${os.tipo}
HPs: ${os.hps}
NAPs: ${os.naps}

Obs: ${os.obs}

`

})

let link="https://wa.me/?text="+encodeURIComponent(texto)
window.open(link)

}

function exportarJSON(){

let dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(banco))
let a = document.createElement("a")
a.href=dataStr
a.download="backup_mdu.json"
a.click()

}
