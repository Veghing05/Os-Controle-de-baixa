
function abrirDashboard(){

let banco = JSON.parse(localStorage.getItem("mduOS")) || []

let total=banco.length
let mdu=banco.filter(o=>o.tipo=="MDU Construção").length
let manut=banco.filter(o=>o.tipo=="Manutenção").length
let drop=banco.filter(o=>o.tipo=="Troca Drop").length

alert(`📊 PRODUÇÃO

OS Totais: ${total}

MDU Construção: ${mdu}

Manutenção: ${manut}

Troca Drop: ${drop}`)

}
